import React, { memo } from 'react';

const TrainingDataManager = memo(() => {
    return (
        <div className="p-4">
            <h2 className="text-xl font-bold text-white">Training Data Manager</h2>
            <p className="text-gray-400">Component is being reconstructed...</p>
        </div>
    );
});

export default TrainingDataManager;
