/**
 * Main App Component wrapper - Imports from OracleOnlyApp for backwards compatibility
 */

import OracleOnlyApp from './OracleOnlyApp';

export default OracleOnlyApp;
